import json
from datetime import datetime

def calculer_moyenne_occupation_par_jour(file_path):
    with open(file_path, 'r') as file:
        data = json.load(file)

    moyennes_par_jour = {}

    for parking_name, parking_data in data.items():
        if 'index' in parking_data['data'] and 'values' in parking_data['data']:
            for index, value in zip(parking_data['data']['index'], parking_data['data']['values']):
                jour = datetime.fromisoformat(index.split('.')[0]).date()
                key = (parking_name, jour)

                if key not in moyennes_par_jour:
                    moyennes_par_jour[key] = {'total_occupation': 0, 'total_entries': 0}

                moyennes_par_jour[key]['total_occupation'] += value
                moyennes_par_jour[key]['total_entries'] += 1

    moyennes_finales = {}

    for key, values in moyennes_par_jour.items():
        parking_name, jour = key
        moyenne = values['total_occupation'] / values['total_entries'] if values['total_entries'] > 0 else 0
        if parking_name not in moyennes_finales:
            moyennes_finales[parking_name] = {}
        moyennes_finales[parking_name][str(jour)] = moyenne

    return moyennes_finales

def enregistrer_resultats_dans_fichier(moyennes, nom_fichier):
    with open(nom_fichier, 'w') as file:
        for parking_name, moyennes_jour in moyennes.items():
            file.write(f"Park: {parking_name}\n")
            for jour, moyenne in moyennes_jour.items():
                file.write(f"   Jour: {jour}, Moyenne: {moyenne}\n")

# Remplacez 'Données_stations/total.json' par le chemin réel de votre fichier JSON
chemin_fichier_json = 'Donnée_stations/total.json'
nom_fichier_resultats = 'resultats_moyennes_bikes.txt'

moyennes = calculer_moyenne_occupation_par_jour(chemin_fichier_json)
enregistrer_resultats_dans_fichier(moyennes, nom_fichier_resultats)

print(f"Les résultats ont été enregistrés dans le fichier : {nom_fichier_resultats}")
