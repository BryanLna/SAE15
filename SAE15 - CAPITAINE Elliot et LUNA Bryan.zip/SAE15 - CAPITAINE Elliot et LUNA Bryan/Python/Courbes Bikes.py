import json
import matplotlib.pyplot as plt


def plot_station_curves(station_data):
    dates = station_data["data"]["index"]
    values = station_data["data"]["values"]

    plt.plot(dates, values)


def plot_grouped_stations(stations_data):
    num_stations = len(stations_data)

    for i in range(0, num_stations, 10):
        plt.figure(figsize=(10, 6))
        for j in range(i, min(i + 10, num_stations)):
            station_data = stations_data[j]
            plot_station_curves(station_data)
            plt.title(f"Group {i // 10 + 1}")
        plt.xlabel("Date")
        plt.ylabel("Taux d'occupation")
        plt.legend([f"Station {j + 1}" for j in range(i, min(i + 10, num_stations))])
        plt.show()


def main():
    with open("Données_stations/total.json", "r") as file:
        data = json.load(file)

    for station_id, station_data in data.items():
        plot_grouped_stations(station_data)


if __name__ == "__main__":
    main()
