import requests
import json
import os
from datetime import datetime, timedelta

# Création du dossier "Données" s'il n'existe pas
folder_path = "Données"
os.makedirs(folder_path, exist_ok=True)

stations_url = "https://portail-api-data.montpellier3m.fr/bikestation?limit=1000"
timeseries_url_template = "https://portail-api-data.montpellier3m.fr/bikestation_timeseries/{}/attrs/availableBikeNumber"

# Récupération des données des stations
response_stations = requests.get(stations_url)
stations_data = response_stations.json()

# Dates de début et de fin
start_date = datetime(2023, 2, 1)
end_date = datetime(2023, 2, 15)

# Interval d'échantillonnage
sample_interval = timedelta(hours=2)

# Dictionnaire pour stocker les données par parking
parking_data = {}

# Récupération de l'historique pour les stations de 1 à 62
for i in range(1, 63):
    station_id = f"urn:ngsi-ld:station:{str(i).zfill(3)}"
    target_station = next((station for station in stations_data if station['id'] == station_id), None)

    if target_station:
        # Initialisation des données pour la station spécifique
        parking_data[station_id] = []

        # Récupération de l'historique jour par jour avec l'intervalle spécifié
        current_date = start_date
        while current_date <= end_date:
            params = {
                "fromDate": current_date.strftime("%Y-%m-%dT%H:%M:%S"),
                "toDate": (current_date + sample_interval).strftime("%Y-%m-%dT%H:%M:%S"),
            }
            timeseries_url = timeseries_url_template.format(station_id)
            response_timeseries = requests.get(timeseries_url, params=params)

            if response_timeseries.status_code == 200:
                timeseries_data = response_timeseries.json()
                parking_data[station_id].append({"date": current_date.isoformat(), "data": timeseries_data})
            else:
                print(f"Erreur lors de la récupération de l'historique pour la station {i}. Code d'erreur : {response_timeseries.status_code}")

            current_date += sample_interval

        # Enregistrement des données dans un fichier texte dans le dossier "Données"
        filename = os.path.join(folder_path, f"parking{i}.json")
        with open(filename, "w") as file:
            json.dump(parking_data[station_id], file, indent=4)

        print(f"Historique de la station {i} enregistré dans le fichier {filename}.")
    else:
        print(f"La station {i} n'a pas été trouvée dans les données des stations.")

# Enregistrement des données totales dans un fichier texte
total_filename = os.path.join(folder_path, "total.json")
with open(total_filename, "w") as total_file:
    json.dump(parking_data, total_file, indent=4)

print(f"Données totales enregistrées dans le fichier {total_filename}.")
