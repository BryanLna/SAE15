import json
import matplotlib.pyplot as plt
from datetime import datetime
from itertools import islice

# Charger les données des noms de parkings depuis le fichier JSON
with open('parking_names.json', 'r') as names_file:
    names_data = json.load(names_file)

# Charger les données des places disponibles depuis le fichier JSON
with open('Données_parking/total.json', 'r') as data_file:
    data = json.load(data_file)

# Associer les noms de parkings aux données
parkings_with_names = {names_data['parking_names'][i]: details for i, (_, details) in enumerate(data.items())}


# Fonction pour convertir les dates au format datetime
def convert_to_datetime(date_str):
    return datetime.strptime(date_str, "%Y-%m-%dT%H:%M:%S.%f%z")


# Fonction pour générer le graphique
def generate_subplot(ax, parkings, title):
    ax.set_title(title)

    for parking, details in parkings.items():
        index = [convert_to_datetime(date) for date in details['index']]
        values = details['values']
        ax.plot(index, values, label=parking)

    ax.set_xlabel('Date et heure')
    ax.set_ylabel('Nombre de places disponibles')
    ax.legend()
    ax.grid(True)


# Générer les graphiques sur la même page
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 12))

# Diviser les parkings en deux groupes
half_parkings = len(parkings_with_names) // 2
first_half = dict(islice(parkings_with_names.items(), half_parkings))
second_half = dict(islice(parkings_with_names.items(), half_parkings, None))

generate_subplot(ax1, first_half, 'Première moitié des parkings')
generate_subplot(ax2, second_half, 'Deuxième moitié des parkings')

plt.tight_layout()
plt.show()
