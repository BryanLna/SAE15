import requests
import json

url = "https://portail-api-data.montpellier3m.fr/offstreetparking?limit=1000"

# Faire une requête GET à l'API
response = requests.get(url)

# Vérifier si la requête a réussi (code de statut 200)
if response.status_code == 200:
    # Charger les données JSON
    data = response.json()

    # Extraire les noms des parkings
    parking_names = [parking['name']['value'] for parking in data]

    # Créer un dictionnaire avec les noms des parkings
    result = {"parking_names": parking_names}

    # Sauvegarder le dictionnaire dans un fichier JSON
    with open('parking_names.json', 'w', encoding='utf-8') as json_file:
        json.dump(result, json_file, ensure_ascii=False, indent=4)
else:
    print(f"La requête a échoué avec le code de statut {response.status_code}")
