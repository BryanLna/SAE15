import requests
import json
import os
from datetime import datetime, timedelta

# Partie 1 - Récupération des données historiques

# Création du dossier "Données" s'il n'existe pas
folder_path = "Données_parking"
os.makedirs(folder_path, exist_ok=True)

# Initialisation de la structure de données pour stocker toutes les données
all_data = {}

# API en temps réel des places de stationnement des vélos
realtime_url = "https://portail-api-data.montpellier3m.fr/offstreetparking?limit=1000"
response_realtime = requests.get(realtime_url)
realtime_data = response_realtime.json()

# Dates de début et de fin de la période demandée
start_date = datetime(2023, 2, 1)
end_date = datetime(2023, 2, 28)

# Récupération de l'historique pour les parkings de 1 à 4
for parking_id in range(1, 24):
    parking_url_template = "https://portail-api-data.montpellier3m.fr/parking_timeseries/urn%3Angsi-ld%3Aparking%3A{}/attrs/availableSpotNumber"

    # Récupération de l'historique pour le parking spécifique
    params = {"fromDate": start_date.isoformat(), "toDate": end_date.isoformat()}
    parking_url = parking_url_template.format(str(parking_id).zfill(3))
    response_parking = requests.get(parking_url, params=params)

    if response_parking.status_code == 200:
        parking_data = response_parking.json()

        # Ajout des données du parking actuel à la structure de données
        all_data[f"parking{parking_id}"] = parking_data

        # Enregistrement des données dans un fichier texte dans le dossier "Données"
        filename = os.path.join(folder_path, f"parking{parking_id}.json")
        with open(filename, "w") as file:
            json.dump(parking_data, file, indent=4)

        print(f"Historique du parking {parking_id} enregistré dans le fichier {filename}.")
    else:
        print(
            f"Erreur lors de la récupération de l'historique pour le parking {parking_id}. Code d'erreur : {response_parking.status_code}")

# Enregistrement des données de la structure complète dans un fichier "total.json"
total_filename = os.path.join(folder_path, "total.json")
with open(total_filename, "w") as total_file:
    json.dump(all_data, total_file, indent=4)

print(f"Données historiques enregistrées dans le fichier {total_filename}.")
